/*
 * Copyright (c) 2020, Instituto Politécnico de Viana do Castelo - Portugal (IPVC).
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the Institute nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE UM AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE UM OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/*******************************************************************************
*                                 Application                                  *
*******************************************************************************/

#define CONF_SETUP_INTERVAL CLOCK_SECOND*60
#define CONF_SEND_INTERVAL CLOCK_SECOND*1

/*******************************************************************************
*                                     UIP                                      *
*******************************************************************************/

//#define QUEUEBUF_CONF_NUM		8
//#define UIP_CONF_BUFFER_SIZE	140

/*******************************************************************************
*                                     RPL                                      *
*******************************************************************************/

//#define RPL_CONF_OF rpl_mrhof
#define RPL_CONF_OF rpl_of_0

// RPL_CONF_DIO_INTERVAL_MIN 12 ~= 4s
// RPL_CONF_DIO_INTERVAL_MIN 16 ~= 65s
#define RPL_CONF_DIO_INTERVAL_MIN 16

// RPL_CONF_DIO_INTERVAL_DOUBLINGS 4 ~= 1 minuto
// RPL_CONF_DIO_INTERVAL_DOUBLINGS 6 ~= 4 minutos
// RPL_CONF_DIO_INTERVAL_DOUBLINGS 8 ~= 17 minutos
// RPL_CONF_DIO_INTERVAL_DOUBLINGS 10 ~= 70 minutos
#define RPL_CONF_DIO_INTERVAL_DOUBLINGS 10

/*******************************************************************************
*                                     MAC                                      *
*******************************************************************************/

//#define CSMA_CONF_MAX_MAC_TRANSMISSIONS 1

#define NETSTACK_CONF_RDC_CHANNEL_CHECK_RATE 32
//#define NETSTACK_CONF_RDC_CHANNEL_CHECK_RATE 8
#define NETSTACK_CONF_RDC nullrdc_driver
//#define NETSTACK_CONF_RDC contikimac_driver

/*******************************************************************************
*                                   Radio                                      *
*******************************************************************************/

// Current consumption on the radio receiving 19.7 mA.
// The current comsumption of the radio transmission depends on the tx power used.
#define RADIO_TX_POWER_0dBm  31 //   0 dbm 17.4 mA
#define RADIO_TX_POWER_1dBm  27 //  -1 dbm 16.5 mA
#define RADIO_TX_POWER_3dBm  23 //  -3 dbm 15.2 mA
#define RADIO_TX_POWER_5dBm  19 //  -5 dbm 13.9 mA
#define RADIO_TX_POWER_7dBm  15 //  -7 dbm 12.5 mA
#define RADIO_TX_POWER_10dBm 11 // -10 dbm 11.2 mA
#define RADIO_TX_POWER_15dBm  7 // -15 dbm  9.9 mA
#define RADIO_TX_POWER_25dBm  3 // -25 dbm  8.5 mA

#define CONF_CC2420_TX_POWER RADIO_TX_POWER_10dBm

#define CC2420_CONF_CHANNEL 15
//#define CC2420_CONF_CHANNEL 26

/*******************************************************************************
*                                 RPL Repair                                   *
*******************************************************************************/

//#define RPL_GLOBAL_REPAIR_PERIOD CLOCK_SECOND * 60 * 1

/*******************************************************************************
*                                     End                                      *
*******************************************************************************/

