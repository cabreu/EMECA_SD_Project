/*
 * Copyright (c) 2020, Instituto Politécnico de Viana do Castelo - Portugal (IPVC).
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright notice, 
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the Institute nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE UM AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE UM OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/**
 * \addtogroup sink
 * @{
 * \file       sink.c 
 * \authors    Carlos Abreu
 *
 * \brief Sink Node.
 */

#include "sink.h"

/*******************************************************************************
*                                   Defines                                    *
*******************************************************************************/


/*******************************************************************************
*                               Global Variables                               *
*******************************************************************************/

//static tcpip_msg_t temp_out_msg;
static tcpip_msg_t temp_imput_msg;

/*******************************************************************************
*                                  Functions                                   *
*******************************************************************************/

static void udp_app_call(char *data, uip_ipaddr_t* srcipaddr)
{
	memset(&temp_imput_msg, '\0', sizeof(temp_imput_msg));
	memcpy(&temp_imput_msg, data, sizeof(temp_imput_msg));

	if (temp_imput_msg.nodeid <= 0) return;

	PRINTF("SOF R: NodeID %d SeqN %lu DATA %s EOF\n",
		temp_imput_msg.nodeid, 
		temp_imput_msg.seqno, 
		temp_imput_msg.data);

	return;
}

/*******************************************************************************
 *                                  Processes                                   *
*******************************************************************************/

PROCESS(sink_process, "Sink process");
AUTOSTART_PROCESSES(&sink_process);

PROCESS_THREAD(sink_process, ev, data)
{
	PROCESS_BEGIN();
	PRINTF("SINK NODE STARTED ...\n");

	SENSORS_ACTIVATE(button_sensor);

	udp_server_start();
	udp_server_add_listener(&udp_app_call);
	PROCESS_PAUSE();

	rpl_router_start();
	PROCESS_PAUSE();
	
	while(1)
	{		
		PROCESS_YIELD();
	}

	PROCESS_END();
}
/*******************************************************************************
*                                     End                                      *
*******************************************************************************/
/** @} */
